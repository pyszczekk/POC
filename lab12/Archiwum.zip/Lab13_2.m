close all;
clearvars;
clc;

lilia = imread('lilia.png');
load maska.mat

liliaFft = fft2(lilia);
liliaDct = dct2(lilia);

figure;
subplot(1,3,1);
imshow(lilia);
subplot(1,3,2);
imshow(log10(abs(liliaFft)+1),[]);
subplot(1,3,3);
imshow(log10(abs(liliaDct)+1),[]);

maskSize = [8 8];

lilia2Dct = blkproc(lilia,maskSize,@dct2);

redukcja = @(blok_danych) maska .* blok_danych;

liliaRed = blkproc(lilia2Dct,maskSize,redukcja);

liliaRed = blkproc(liliaRed,maskSize,@idct2);

figure;
subplot(1,3,1);
imshow(lilia);
subplot(1,3,2);
imshow(uint8(liliaRed));
subplot(1,3,3);
imshow(imabsdiff(lilia,uint8(liliaRed)),[]);
