close all;
clearvars;
clc;

mglawica = imread('mglawica.png');

mglawicaFft = fft2(mglawica);
mglawicaDct = dct2(mglawica);

figure;
subplot(1,3,1);
imshow(mglawica);
subplot(1,3,2);
imshow(log10(abs(mglawicaFft)+1),[]);
subplot(1,3,3);
imshow(log10(abs(mglawicaDct)+1),[]);

mglawicaIdct = idct2(mglawicaDct);

figure;
subplot(1,3,1);
imshow(mglawica);
subplot(1,3,2);
imshow(uint8(mglawicaIdct));
subplot(1,3,3);
imshow(imabsdiff(mglawica,uint8(mglawicaIdct)),[]);


