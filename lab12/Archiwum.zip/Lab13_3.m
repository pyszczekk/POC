close all;
clearvars;
clc;

mglawicaK = imread('mglawica_kolor.png');

load tablice_kwantyzacji.mat;

clusterSize = [8 8];

c = 7;

mglawicaKYCbCr = rgb2ycbcr(mglawicaK);

YPart =  mglawicaKYCbCr(:,:,1);
CbPart = mglawicaKYCbCr(:,:,2);
CrPart = mglawicaKYCbCr(:,:,3);

YPartDCT = blkproc(YPart,clusterSize,@dct2);
CbPartDCT = blkproc(CbPart,clusterSize,@dct2);
CrPartDCT = blkproc(CrPart,clusterSize,@dct2);

redukcjaY = @(blok) round(blok ./ (c * Qy));
redukcjaC = @(blok) round(blok ./ (c * Qc));

YPartDCTRed = blkproc(YPartDCT,clusterSize,redukcjaY);
CbPartDCTRed = blkproc(CbPartDCT,clusterSize,redukcjaC);
CrPartDCTRed = blkproc(CrPartDCT,clusterSize,redukcjaC);

[org rle huffman] = symbolEncoderYCbCr(mglawicaKYCbCr,YPartDCTRed,CbPartDCTRed,CrPartDCTRed);

display('Wsp�czynnik kompresji c: ');
display(c);

display('Rozmiar obrazu RLE w stosunku do oryginalnego: ');
display((rle/org));

display('Rozmiar obrazu Huffmana w stosunku do oryginalnego: ');
display((huffman/org));

dekwantyzacjaY = @(blok) blok .* (c * Qy);
dekwantyzacjaC = @(blok) blok .* (c * Qc);

YPartDCTUnRed = blkproc(YPartDCTRed,clusterSize,dekwantyzacjaY);
CbPartDCTUnRed = blkproc(CbPartDCTRed,clusterSize,dekwantyzacjaC);
CrPartDCTUnRed = blkproc(CrPartDCTRed,clusterSize,dekwantyzacjaC);

YPartIDCT = blkproc(YPartDCTUnRed,clusterSize,@idct2);
CbPartIDCT = blkproc(CbPartDCTUnRed,clusterSize,@idct2);
CrPartIDCT = blkproc(CrPartDCTUnRed,clusterSize,@idct2);

mglawicaIDTCYCbCr(:,:,1) = YPartIDCT;
mglawicaIDTCYCbCr(:,:,2) = CbPartIDCT;
mglawicaIDTCYCbCr(:,:,3) = CrPartIDCT;

mglawicaIDTC = ycbcr2rgb(uint8(mglawicaIDTCYCbCr));

figure;
subplot(1,2,1);
imshow(mglawicaK);
subplot(1,2,2);
imshow(mglawicaIDTC,[]);